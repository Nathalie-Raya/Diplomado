package com.tallercmovil.videogames

import android.R
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.tallercmovil.videogames.db.DBHelper

import android.widget.Toast
import com.tallercmovil.videogames.databinding.ActivityInsertBinding
import com.tallercmovil.videogames.db.DbGames
import java.util.*

class InsertActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    private lateinit var binding: ActivityInsertBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInsertBinding.inflate(layoutInflater)
        setContentView(binding.root)




        val listado= ArrayAdapter<String>(this,R.layout.simple_spinner_dropdown_item)
        listado.addAll(Arrays.asList("Compatibilidad","XBOX","PS4","SWITCH"))
        binding.spCompatible.onItemSelectedListener=this
        binding.spCompatible.adapter=listado


    }

    fun click(view: View) {


        val dbGames = DbGames(this)
        val compatible = binding.spCompatible.getSelectedItem().toString()
       // Toast.makeText(this, "Resultado de compatible$compatible", Toast.LENGTH_LONG) .show()
        with(binding){

            if(!tietTitulo.text.toString().isEmpty() && !tietGenre.text.toString().isEmpty() && !tietDeveloper.text.toString().isEmpty() && compatible!="Compatibilidad"){
                val id = dbGames.insertGame(tietTitulo.text.toString(), tietGenre.text.toString(), tietDeveloper.text.toString(), compatible)

                if(id > 0) { //el registro se insertó correctamente
                    Toast.makeText(this@InsertActivity, "Registro guardado exitosamente", Toast.LENGTH_LONG).show()

                    //Reiniciamos las cajas de texto
                    tietTitulo.setText("")
                    tietGenre.setText("")
                    tietDeveloper.setText("")
                    spCompatible.setSelection(0)
                    tietTitulo.requestFocus()
                }else{
                    Toast.makeText(this@InsertActivity, "Error al guardar el registro", Toast.LENGTH_LONG).show()
                }
            }else{
                Toast.makeText(this@InsertActivity, "Por favor llene todos los campos", Toast.LENGTH_LONG).show()

                //Para mandar un error en una caja de texto especíica
                //tietTitulo.text = "Por favor agrega un título"
            }

        }


    }

    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this, MainActivity::class.java))
    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
    }
}