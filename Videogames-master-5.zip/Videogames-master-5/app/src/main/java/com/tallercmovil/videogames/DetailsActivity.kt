package com.tallercmovil.videogames

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.tallercmovil.videogames.databinding.ActivityDetailsBinding
import com.tallercmovil.videogames.db.DbGames
import com.tallercmovil.videogames.model.Game
import java.util.*

class DetailsActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    private lateinit var binding: ActivityDetailsBinding

    private lateinit var dbGames: DbGames
    var game: Game? = null
    var id:Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val listado = ArrayAdapter<String>(
            this, android.R.layout.simple_spinner_dropdown_item
        )
        listado.addAll(Arrays.asList("Compatibilidad","XBOX","PS4","SWITCH"))
        binding.spCompatible.onItemSelectedListener= this
        binding.spCompatible.adapter=listado



        if(savedInstanceState == null){
            val bundle = intent.extras
            if(bundle != null){
                id = bundle.getInt("ID", 0)

            }
        }else{
            id = savedInstanceState.getSerializable("ID") as Int
        }



        dbGames = DbGames(this)

        game = dbGames.getGame(id)
        //Toast.makeText(this, "Error $game", Toast.LENGTH_LONG).show()
        if(game != null){
            with(binding){
                tietTitulo.setText(game?.title)
                tietGenre.setText(game?.genre)
                tietDeveloper.setText(game?.developer)
                //spCompatible.getSelectedItem().toString()
                val bdcompatible=(game?.compatible)
                if (bdcompatible=="XBOX") {
                    spCompatible.setSelection(1)
                }
                else if (bdcompatible=="PS4") {
                    spCompatible.setSelection(2)
                }
                else if (bdcompatible=="SWITCH") {
                    spCompatible.setSelection(3)
                }
                //Para que no se abra el teclado al momento de hacer click en los TextInputEditText
                tietTitulo.inputType = InputType.TYPE_NULL
                tietGenre.inputType = InputType.TYPE_NULL
                tietDeveloper.inputType = InputType.TYPE_NULL


            }
        }
    }


    fun click(view: View) {
        when(view.id){
            R.id.btnEdit -> {
                val intent = Intent(this, EditActivity::class.java)
                intent.putExtra("ID", id)
                startActivity(intent)
                finish()
            }

            R.id.btnDelete -> {
                AlertDialog.Builder(this)
                    .setTitle("Confirmación")
                    .setMessage("¿Realmente deseas eliminar el juego ${game?.title}?")
                    .setPositiveButton("Sí", DialogInterface.OnClickListener { dialogInterface, i ->
                        if(dbGames.deleteGame(id)){
                            Toast.makeText(this, "Registro eliminado exitosamente", Toast.LENGTH_LONG).show()
                            startActivity(Intent(this, MainActivity::class.java))
                            finish()
                        }
                    })
                    .setNegativeButton("No", DialogInterface.OnClickListener { dialogInterface, i ->
                        //Si se desea realizar alguna acción cuando el usuario selecciona NO
                    })
                    .show()
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this, MainActivity::class.java))
    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
    }
}