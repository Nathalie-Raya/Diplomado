package com.tallercmovil.videogames.model

data class Game(var id: Int, var title: String, var genre: String, var developer: String, var compatible: String)
