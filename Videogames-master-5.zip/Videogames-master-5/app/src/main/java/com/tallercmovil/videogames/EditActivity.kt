package com.tallercmovil.videogames

import android.R
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import com.tallercmovil.videogames.databinding.ActivityEditBinding
import com.tallercmovil.videogames.db.DbGames
import com.tallercmovil.videogames.model.Game
import java.util.*

class EditActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener  {

    private lateinit var binding: ActivityEditBinding

    private lateinit var dbGames: DbGames
    var game: Game? = null
    var id: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val listado = ArrayAdapter<String>(
            this, R.layout.simple_spinner_dropdown_item
        )
        listado.addAll(Arrays.asList("Compatibilidad","XBOX","PS4","SWITCH"))
        binding.spCompatible.onItemSelectedListener= this
        binding.spCompatible.adapter=listado


        if(savedInstanceState == null){
            val bundle = intent.extras
            if(bundle != null){
                id = bundle.getInt("ID", 0)
            }
        }else{
            id = savedInstanceState.getSerializable("ID") as Int
        }

        dbGames = DbGames(this)

        game = dbGames.getGame(id)

        if(game != null){
            with(binding){
                tietTitulo.setText(game?.title)
                tietGenre.setText(game?.genre)
                tietDeveloper.setText(game?.developer)
                //spCompatible.setSelection(0)
                val bdcompatible=(game?.compatible)
                if (bdcompatible=="XBOX") {
                    spCompatible.setSelection(1)
                }
                else if (bdcompatible=="PS4") {
                    spCompatible.setSelection(2)
                }
                else if (bdcompatible=="SWITCH") {
                    spCompatible.setSelection(3)
                }

            }
        }
    }

    fun click(view: View) {

        val genero = binding.spCompatible.getSelectedItem().toString()
        with(binding){
            if(!tietTitulo.text.toString().isEmpty() && !tietGenre.text.toString().isEmpty() && !tietDeveloper.text.toString().isEmpty()&& genero!="Compatibilidad"){
                if(dbGames.updateGame(id, tietTitulo.text.toString(), tietGenre.text.toString(), tietDeveloper.text.toString(),spCompatible.getSelectedItem().toString())){
                    Toast.makeText(this@EditActivity, "Registro actualizado exitosamente", Toast.LENGTH_LONG).show()
                    val intent = Intent(this@EditActivity, DetailsActivity::class.java)
                    intent.putExtra("ID", id)
                    startActivity(intent)
                    finish()
                }else{
                    Toast.makeText(this@EditActivity, "Error al actualizar el registro", Toast.LENGTH_LONG).show()
                }
            }else{
                Toast.makeText(this@EditActivity, "Ningún campo puede quedar vacío", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
    }
}